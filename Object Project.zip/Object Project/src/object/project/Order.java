/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package object.project;

/**
 *
 * @author green
 */

public class Order { 

    private Customer Customer; 

    public Date dateOfOrder; 

    private Furniture[] Items; 

    private double totalPrice; 
    
    public int day,month,year;

  

    public Order(Customer customer, int day, int month, int year, Furniture[] Items) { 

        Customer = customer; 

        dateOfOrder = new Date(day,month,year) ; 

        Items = Items; 

        calculateTotalPrice(); 

    } 

  

    private void calculateTotalPrice() { 

        totalPrice = 0; 

        for (Furniture item : Items) { 

            totalPrice += item.getPrice(); 

        } 

    } 

  

    @Override 

    public String toString() { 

        StringBuilder sb = new StringBuilder(); 

        sb.append("Order Details:\n"); 

        //sb.append("Customer: ").append(CustomerNameOrder.getName()).append("\n"); 

        sb.append("Date of Order: ").append(dateOfOrder).append("\n"); 

        sb.append("Items:\n"); 

        for (Furniture item : Items) { 

            sb.append("- ").append(item).append("\n"); 

        } 

        sb.append("Total Price: ").append(totalPrice); 

        return sb.toString(); 

    } 

} 

