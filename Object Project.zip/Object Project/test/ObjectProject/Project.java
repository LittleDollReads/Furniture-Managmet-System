/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package ObjectProject;

import object.project.Customer;
import object.project.Date;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author green
 */
public class Project {
    
    public Project() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }
    
     static Customer testCustomer = new Customer(); 
     Date testDate = new Date();
     
     @Test
     public void testCustomer() {
         
         
     }
     /**
     
     @Test 
     public void Date(int Day, int Month, int Year) {
        setDay(Day);
        setMonth(Month);
        setYear(Year); 
        
        int actual = Date.Date(day,month,year);
        int expected = Date.Date(1,1,2000);
        
    }
  
     
     @Test
     public int testDate() {
        
        int day = 1, month = 1, year = 2000;
                
        int actual = Date.Date(1,1,2000);
        int expected = Date.Date(1,1,2000);
        assertEquals(expected, actual);
        
        
    }
**/
    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
