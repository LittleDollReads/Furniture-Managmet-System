/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package object.project;

/**
 *
 * @author green
 */
public class Main {
    
    public static void main(String[] args) {
        // TODO code application logic here
        FurnitureGUI.main(args);
    }
    
}
