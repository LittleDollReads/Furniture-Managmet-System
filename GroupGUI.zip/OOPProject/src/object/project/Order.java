package object.project;

import java.util.Date; 
public class Order {
    private Customer customer;
    private Date orderDate; // Date of order
    private Furniture[] items; // Array of ordered furniture items
    private int itemCount; // Number of items in the order

    public Order(Customer customer, Date orderDate, int maxItems) {
        this.customer = customer;
        this.orderDate = orderDate;
        this.items = new Furniture[maxItems];
        this.itemCount = 0;
    }

    // Getter and setter methods for Customer, orderDate, and itemCount

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }

    public int getItemCount() {
        return itemCount;
    }

    // Method to add furniture item to the order
    public void addItem(Furniture item) {
        if (itemCount < items.length) {
            items[itemCount++] = item;
        } else {
            System.out.println("Cannot add more items. Order is full.");
        }
    }

    // Method to calculate total price of the order
    public int getTotalPrice() {
        int totalPrice = 0;
        for (int i = 0; i < itemCount; i++) {
            totalPrice += items[i].getPrice();
        }
        return totalPrice;
    }
}
